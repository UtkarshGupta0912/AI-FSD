// =============================================
// Employee Controller — controllers/employeeController.js
// Contains all CRUD operations for Employee
// Uses employeeId (user-provided) for all lookups
// =============================================

const Employee = require("../models/employeeModel");

// -----------------------------------------
// @desc    Create a new employee
// @route   POST /api/employees
// @access  Public
// -----------------------------------------
const createEmployee = async (req, res) => {
  try {
    const { employeeId, fullName, email, phoneNumber, department, designation, salary, dateOfJoining, employmentType, status } = req.body;

    // Check if employee with same employeeId already exists
    const existingId = await Employee.findOne({ employeeId });
    if (existingId) {
      return res.status(400).json({
        success: false,
        message: "An employee with this Employee ID already exists",
      });
    }

    // Check if employee with same email already exists
    const existingEmail = await Employee.findOne({ email });
    if (existingEmail) {
      return res.status(400).json({
        success: false,
        message: "An employee with this email already exists",
      });
    }

    // Create a new employee document
    const employee = await Employee.create({
      employeeId,
      fullName,
      email,
      phoneNumber,
      department,
      designation,
      salary,
      dateOfJoining,
      employmentType,
      status,
    });

    // Respond with the created employee
    res.status(201).json({
      success: true,
      message: "Employee created successfully",
      data: employee,
    });
  } catch (error) {
    // Handle Mongoose validation errors
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: "Validation Error",
        errors: messages,
      });
    }
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// -----------------------------------------
// @desc    Get all employees
// @route   GET /api/employees
// @access  Public
// -----------------------------------------
const getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: employees.length,
      data: employees,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// -----------------------------------------
// @desc    Get a single employee by employeeId
// @route   GET /api/employees/:id
// @access  Public
// -----------------------------------------
const getEmployeeById = async (req, res) => {
  try {
    // Find by the user-provided employeeId field
    const employee = await Employee.findOne({ employeeId: req.params.id });

    // If employee not found
    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    res.status(200).json({
      success: true,
      data: employee,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// -----------------------------------------
// @desc    Update an employee by employeeId
// @route   PUT /api/employees/:id
// @access  Public
// -----------------------------------------
const updateEmployee = async (req, res) => {
  try {
    // Find by employeeId and update
    const employee = await Employee.findOneAndUpdate(
      { employeeId: req.params.id },
      req.body,
      {
        new: true,            // Return the updated document
        runValidators: true,  // Run schema validators on update
      }
    );

    // If employee not found
    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Employee updated successfully",
      data: employee,
    });
  } catch (error) {
    // Handle Mongoose validation errors
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: "Validation Error",
        errors: messages,
      });
    }
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// -----------------------------------------
// @desc    Delete an employee by employeeId
// @route   DELETE /api/employees/:id
// @access  Public
// -----------------------------------------
const deleteEmployee = async (req, res) => {
  try {
    // Find by employeeId and delete
    const employee = await Employee.findOneAndDelete({ employeeId: req.params.id });

    // If employee not found
    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Employee deleted successfully",
      data: employee,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// -----------------------------------------
// @desc    Search employees by name or department
// @route   GET /api/employees/search?name=xyz&department=IT
// @access  Public
// -----------------------------------------
const searchEmployees = async (req, res) => {
  try {
    const { name, department } = req.query;

    // Build a dynamic query object
    let query = {};

    // Search by name using case-insensitive regex
    if (name) {
      query.fullName = { $regex: name, $options: "i" };
    }

    // Search by department (exact match, case-insensitive)
    if (department) {
      query.department = { $regex: `^${department}$`, $options: "i" };
    }

    // If no search parameters provided
    if (!name && !department) {
      return res.status(400).json({
        success: false,
        message: "Please provide a search query (name or department)",
      });
    }

    const employees = await Employee.find(query).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: employees.length,
      data: employees,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

// Export all controller functions
module.exports = {
  createEmployee,
  getAllEmployees,
  getEmployeeById,
  updateEmployee,
  deleteEmployee,
  searchEmployees,
};
