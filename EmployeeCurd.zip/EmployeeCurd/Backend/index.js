// =============================================
// Server Entry Point — index.js
// Employee Management System REST API
// =============================================

const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const employeeRoutes = require("./routes/employeeRoutes");

// Load environment variables from .env file
dotenv.config();

// Initialize Express application
const app = express();

// -----------------------------------------
// Middleware
// -----------------------------------------

// Parse incoming JSON request bodies
app.use(cors());
app.use(express.json());

// Parse URL-encoded data (for form submissions)
app.use(express.urlencoded({ extended: true }));

// -----------------------------------------
// API Routes
// -----------------------------------------

// Mount employee routes at /api/employees
app.use("/api/employees", employeeRoutes);

// Root route — API health check
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "🚀 Employee Management API is running!",
  });
});

// -----------------------------------------
// Global Error Handling Middleware
// Catches any errors that weren't handled
// in the route handlers / controllers
// -----------------------------------------
app.use((err, req, res, next) => {
  console.error(`❌ Error: ${err.message}`);
  console.error(err.stack);

  res.status(err.statusCode || 500).json({
    success: false,
    message: err.message || "Internal Server Error",
  });
});

// -----------------------------------------
// Handle 404 — Route Not Found
// -----------------------------------------
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.originalUrl} not found`,
  });
});

// -----------------------------------------
// Connect to MongoDB & Start Server
// -----------------------------------------
const PORT = process.env.PORT || 5000;

connectDB()
  .then(() => {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`🚀 Server is running on port ${PORT}`);
      console.log(`📡 API Base URL: /api/employees`);
    });
  })
  .catch((err) => {
    console.error(`❌ Failed to connect to database: ${err.message}`);
    console.error("Starting server without database connection...");
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`⚠️ Server is running on port ${PORT} (WITHOUT database)`);
    });
  });
