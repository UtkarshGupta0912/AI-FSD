// =============================================
// Employee Routes — routes/employeeRoutes.js
// Defines all API endpoints for Employee CRUD
// =============================================

const express = require("express");
const router = express.Router();

// Import controller functions
const {
  createEmployee,
  getAllEmployees,
  getEmployeeById,
  updateEmployee,
  deleteEmployee,
  searchEmployees,
} = require("../controllers/employeeController");

// -----------------------------------------
// IMPORTANT: The /search route must be placed
// BEFORE the /:id route so Express doesn't
// treat "search" as a MongoDB ObjectId.
// -----------------------------------------

// @route   GET /api/employees/search?name=xyz&department=IT
// @desc    Search employees by name or department
router.get("/search", searchEmployees);

// @route   POST /api/employees
// @desc    Create a new employee
router.post("/", createEmployee);

// @route   GET /api/employees
// @desc    Fetch all employees
router.get("/", getAllEmployees);

// @route   GET /api/employees/:id
// @desc    Get a single employee by ID
router.get("/:id", getEmployeeById);

// @route   PUT /api/employees/:id
// @desc    Update employee details
router.put("/:id", updateEmployee);

// @route   DELETE /api/employees/:id
// @desc    Delete an employee
router.delete("/:id", deleteEmployee);

module.exports = router;
