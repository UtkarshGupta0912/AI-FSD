// =============================================
// Database Configuration — config/db.js
// Connects to MongoDB using Mongoose
// =============================================

const mongoose = require("mongoose");

/**
 * connectDB
 * Establishes a connection to the MongoDB database
 * using the URI stored in environment variables.
 */
const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      throw new Error(
        "MONGO_URI is not defined. Please set it in your environment variables (Render Dashboard → Environment)."
      );
    }

    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    throw error; // Let the caller handle it instead of killing the process
  }
};

module.exports = connectDB;
