// =============================================
// Employee Model — models/employeeModel.js
// Defines the Mongoose schema for Employee
// =============================================

const mongoose = require("mongoose");

/**
 * Employee Schema
 * Contains all fields with proper validations
 * as required for the Employee Management System.
 */
const employeeSchema = new mongoose.Schema(
  {
    // Unique employee ID (set by the user, e.g., EMP001, EMP002)
    employeeId: {
      type: String,
      required: [true, "Employee ID is required"],
      unique: true,
      trim: true,
    },

    // Full name of the employee
    fullName: {
      type: String,
      required: [true, "Full name is required"],
      trim: true,
      minlength: [2, "Full name must be at least 2 characters"],
      maxlength: [100, "Full name cannot exceed 100 characters"],
    },

    // Email address (must be unique)
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please enter a valid email address",
      ],
    },

    // Phone number of the employee
    phoneNumber: {
      type: String,
      required: [true, "Phone number is required"],
      match: [/^\d{10}$/, "Phone number must be exactly 10 digits"],
    },

    // Department the employee belongs to
    department: {
      type: String,
      required: [true, "Department is required"],
      enum: {
        values: ["HR", "IT", "Finance", "Marketing", "Sales", "Operations", "Engineering"],
        message: "{VALUE} is not a valid department",
      },
    },

    // Job designation / title
    designation: {
      type: String,
      required: [true, "Designation is required"],
      trim: true,
    },

    // Monthly salary (must be a positive number)
    salary: {
      type: Number,
      required: [true, "Salary is required"],
      min: [0, "Salary must be a positive number"],
    },

    // Date when the employee joined
    dateOfJoining: {
      type: Date,
      required: [true, "Date of joining is required"],
    },

    // Type of employment
    employmentType: {
      type: String,
      required: [true, "Employment type is required"],
      enum: {
        values: ["Full-time", "Part-time", "Contract"],
        message: "{VALUE} is not a valid employment type",
      },
    },

    // Current status of the employee
    status: {
      type: String,
      enum: {
        values: ["Active", "Inactive"],
        message: "{VALUE} is not a valid status",
      },
      default: "Active",
    },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt fields automatically
  }
);

// Export the Employee model
const Employee = mongoose.model("Employee", employeeSchema);
module.exports = Employee;
